package ExemploAula;


public interface Animal {
    abstract void comer();
    abstract void dormir();
    abstract void fazerSom();
}
